package ece325_lab_assignment6;

public class MillisPerformanceMeasurement implements PerformanceMeasurement {

}
