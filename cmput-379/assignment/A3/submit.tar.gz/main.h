#ifndef MAIN_H
#define MAIN_H


#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include <pthread.h>
#include <signal.h>
#include <unistd.h>

#include "const.h"
#include "master.h"
#include "tor.h"
#include "utils.h"

using namespace std;


#endif